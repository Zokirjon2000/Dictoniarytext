package uz.pdp.service;

import com.google.gson.Gson;
import uz.pdp.models.Language;
import uz.pdp.models.Translate;
import uz.pdp.models.Word;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class YandexServiceImpl implements YandexService {
    private String BASE_URL = "https://translate.yandex.net/api/v1.5/tr.json/";
    private String KEY = "trnsl.1.1.20200130T120519Z.fccb7f6b081304b3.f4a1f69bd1711c8eed863faf283b69cda3aeef21";
    private Gson gson = new Gson();
    private Scanner scanner = new Scanner(System.in);
    private File file = new File("yandex.txt");

    @Override
    public void getLangs() {
        String data = HttpService.getData(BASE_URL + "getLangs?key=" + KEY);
        Language language = gson.fromJson(data, Language.class);
        List<String> dirs = language.getDirs();
        dirs.add("uz-ru");
        dirs.add("uz-en");
        for (int i = 0; i < dirs.size(); i++) {
            if (i % 10 == 0) {
                System.out.println();
            }
            System.out.print(dirs.get(i) + "\t");
        }
    }

    @Override
    public void translate() {
        System.out.println("Tilni kiriting:");
        String lang = scanner.next();
        scanner = new Scanner(System.in);
        System.out.println("So'z kiriting:");
        String word = scanner.nextLine();

        List<Word> wordList = FileService.getWords(file);
        if (wordList == null) {
            wordList = new ArrayList<>();
        }
        boolean isHave = false;
        for (int i = 0; i < wordList.size(); i++) {
            if (wordList.get(i).getLanguage().equalsIgnoreCase(lang) &&
                    wordList.get(i).getWord().equalsIgnoreCase(word)) {
                System.out.println(wordList.get(i).getTranslate());
                isHave = true;
                break;
            }
        }
        if (!isHave) {
            String word1 = word.replace(" ", "%20");
            String word2 = word1.replace("\'", "%27");
            String data = HttpService.getData(BASE_URL + "translate?key=" + KEY + "&text=" + word2 + "&lang=" + lang);
            Translate translate = gson.fromJson(data, Translate.class);
            System.out.println(translate.getText().get(0));
            Word mainWord = new Word(lang, word, translate.getText().get(0));
            wordList.add(mainWord);
            String s = gson.toJson(wordList);
            FileService.writeFile(file, s);
        }
    }
}
