package uz.pdp.service;

public interface YandexService {

    void getLangs();

    void translate();
}
