package uz.pdp.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import uz.pdp.models.Word;

import java.io.*;
import java.lang.reflect.Type;
import java.util.List;

public class FileService {

    public static void writeFile(File file, String text) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(text.getBytes());
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Word> getWords(File file) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileInputStream fileInputStream = new FileInputStream(file);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String row;
            while ((row = bufferedReader.readLine()) != null) {
                stringBuilder.append(row);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Type type = new TypeToken<List<Word>>() {}.getType();
        Gson gson = new Gson();
        List<Word> wordList = gson.fromJson(stringBuilder.toString(),type);
        return wordList;
    }
}
