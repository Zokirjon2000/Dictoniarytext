package uz.pdp.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Langs implements Serializable {

	@SerializedName("tt")
	private String tt;

	@SerializedName("de")
	private String de;

	@SerializedName("hi")
	private String hi;

	@SerializedName("lo")
	private String lo;

	@SerializedName("pt")
	private String pt;

	@SerializedName("lt")
	private String lt;

	@SerializedName("hr")
	private String hr;

	@SerializedName("lv")
	private String lv;

	@SerializedName("ht")
	private String ht;

	@SerializedName("hu")
	private String hu;

	@SerializedName("yi")
	private String yi;

	@SerializedName("hy")
	private String hy;

	@SerializedName("uk")
	private String uk;

	@SerializedName("mg")
	private String mg;

	@SerializedName("id")
	private String id;

	@SerializedName("mi")
	private String mi;

	@SerializedName("ur")
	private String ur;

	@SerializedName("mk")
	private String mk;

	@SerializedName("pap")
	private String pap;

	@SerializedName("ml")
	private String ml;

	@SerializedName("mn")
	private String mn;

	@SerializedName("af")
	private String af;

	@SerializedName("mr")
	private String mr;

	@SerializedName("uz")
	private String uz;

	@SerializedName("ms")
	private String ms;

	@SerializedName("el")
	private String el;

	@SerializedName("mt")
	private String mt;

	@SerializedName("en")
	private String en;

	@SerializedName("eo")
	private String eo;

	@SerializedName("is")
	private String is;

	@SerializedName("it")
	private String it;

	@SerializedName("am")
	private String am;

	@SerializedName("my")
	private String my;

	@SerializedName("es")
	private String es;

	@SerializedName("zh")
	private String zh;

	@SerializedName("et")
	private String et;

	@SerializedName("eu")
	private String eu;

	@SerializedName("ar")
	private String ar;

	@SerializedName("vi")
	private String vi;

	@SerializedName("mhr")
	private String mhr;

	@SerializedName("ja")
	private String ja;

	@SerializedName("ne")
	private String ne;

	@SerializedName("az")
	private String az;

	@SerializedName("fa")
	private String fa;

	@SerializedName("ro")
	private String ro;

	@SerializedName("nl")
	private String nl;

	@SerializedName("ba")
	private String ba;

	@SerializedName("udm")
	private String udm;

	@SerializedName("ceb")
	private String ceb;

	@SerializedName("no")
	private String no;

	@SerializedName("be")
	private String be;

	@SerializedName("fi")
	private String fi;

	@SerializedName("ru")
	private String ru;

	@SerializedName("bg")
	private String bg;

	@SerializedName("bn")
	private String bn;

	@SerializedName("fr")
	private String fr;

	@SerializedName("jv")
	private String jv;

	@SerializedName("bs")
	private String bs;

	@SerializedName("ka")
	private String ka;

	@SerializedName("si")
	private String si;

	@SerializedName("sk")
	private String sk;

	@SerializedName("sl")
	private String sl;

	@SerializedName("ga")
	private String ga;

	@SerializedName("gd")
	private String gd;

	@SerializedName("ca")
	private String ca;

	@SerializedName("sq")
	private String sq;

	@SerializedName("sr")
	private String sr;

	@SerializedName("kk")
	private String kk;

	@SerializedName("km")
	private String km;

	@SerializedName("su")
	private String su;

	@SerializedName("kn")
	private String kn;

	@SerializedName("sv")
	private String sv;

	@SerializedName("ko")
	private String ko;

	@SerializedName("mrj")
	private String mrj;

	@SerializedName("sw")
	private String sw;

	@SerializedName("gl")
	private String gl;

	@SerializedName("ta")
	private String ta;

	@SerializedName("gu")
	private String gu;

	@SerializedName("ky")
	private String ky;

	@SerializedName("cs")
	private String cs;

	@SerializedName("xh")
	private String xh;

	@SerializedName("pa")
	private String pa;

	@SerializedName("te")
	private String te;

	@SerializedName("cv")
	private String cv;

	@SerializedName("tg")
	private String tg;

	@SerializedName("th")
	private String th;

	@SerializedName("la")
	private String la;

	@SerializedName("cy")
	private String cy;

	@SerializedName("lb")
	private String lb;

	@SerializedName("tl")
	private String tl;

	@SerializedName("pl")
	private String pl;

	@SerializedName("da")
	private String da;

	@SerializedName("he")
	private String he;

	@SerializedName("tr")
	private String tr;

	public void setTt(String tt){
		this.tt = tt;
	}

	public String getTt(){
		return tt;
	}

	public void setDe(String de){
		this.de = de;
	}

	public String getDe(){
		return de;
	}

	public void setHi(String hi){
		this.hi = hi;
	}

	public String getHi(){
		return hi;
	}

	public void setLo(String lo){
		this.lo = lo;
	}

	public String getLo(){
		return lo;
	}

	public void setPt(String pt){
		this.pt = pt;
	}

	public String getPt(){
		return pt;
	}

	public void setLt(String lt){
		this.lt = lt;
	}

	public String getLt(){
		return lt;
	}

	public void setHr(String hr){
		this.hr = hr;
	}

	public String getHr(){
		return hr;
	}

	public void setLv(String lv){
		this.lv = lv;
	}

	public String getLv(){
		return lv;
	}

	public void setHt(String ht){
		this.ht = ht;
	}

	public String getHt(){
		return ht;
	}

	public void setHu(String hu){
		this.hu = hu;
	}

	public String getHu(){
		return hu;
	}

	public void setYi(String yi){
		this.yi = yi;
	}

	public String getYi(){
		return yi;
	}

	public void setHy(String hy){
		this.hy = hy;
	}

	public String getHy(){
		return hy;
	}

	public void setUk(String uk){
		this.uk = uk;
	}

	public String getUk(){
		return uk;
	}

	public void setMg(String mg){
		this.mg = mg;
	}

	public String getMg(){
		return mg;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setMi(String mi){
		this.mi = mi;
	}

	public String getMi(){
		return mi;
	}

	public void setUr(String ur){
		this.ur = ur;
	}

	public String getUr(){
		return ur;
	}

	public void setMk(String mk){
		this.mk = mk;
	}

	public String getMk(){
		return mk;
	}

	public void setPap(String pap){
		this.pap = pap;
	}

	public String getPap(){
		return pap;
	}

	public void setMl(String ml){
		this.ml = ml;
	}

	public String getMl(){
		return ml;
	}

	public void setMn(String mn){
		this.mn = mn;
	}

	public String getMn(){
		return mn;
	}

	public void setAf(String af){
		this.af = af;
	}

	public String getAf(){
		return af;
	}

	public void setMr(String mr){
		this.mr = mr;
	}

	public String getMr(){
		return mr;
	}

	public void setUz(String uz){
		this.uz = uz;
	}

	public String getUz(){
		return uz;
	}

	public void setMs(String ms){
		this.ms = ms;
	}

	public String getMs(){
		return ms;
	}

	public void setEl(String el){
		this.el = el;
	}

	public String getEl(){
		return el;
	}

	public void setMt(String mt){
		this.mt = mt;
	}

	public String getMt(){
		return mt;
	}

	public void setEn(String en){
		this.en = en;
	}

	public String getEn(){
		return en;
	}

	public void setEo(String eo){
		this.eo = eo;
	}

	public String getEo(){
		return eo;
	}

	public void setIs(String is){
		this.is = is;
	}

	public String getIs(){
		return is;
	}

	public void setIt(String it){
		this.it = it;
	}

	public String getIt(){
		return it;
	}

	public void setAm(String am){
		this.am = am;
	}

	public String getAm(){
		return am;
	}

	public void setMy(String my){
		this.my = my;
	}

	public String getMy(){
		return my;
	}

	public void setEs(String es){
		this.es = es;
	}

	public String getEs(){
		return es;
	}

	public void setZh(String zh){
		this.zh = zh;
	}

	public String getZh(){
		return zh;
	}

	public void setEt(String et){
		this.et = et;
	}

	public String getEt(){
		return et;
	}

	public void setEu(String eu){
		this.eu = eu;
	}

	public String getEu(){
		return eu;
	}

	public void setAr(String ar){
		this.ar = ar;
	}

	public String getAr(){
		return ar;
	}

	public void setVi(String vi){
		this.vi = vi;
	}

	public String getVi(){
		return vi;
	}

	public void setMhr(String mhr){
		this.mhr = mhr;
	}

	public String getMhr(){
		return mhr;
	}

	public void setJa(String ja){
		this.ja = ja;
	}

	public String getJa(){
		return ja;
	}

	public void setNe(String ne){
		this.ne = ne;
	}

	public String getNe(){
		return ne;
	}

	public void setAz(String az){
		this.az = az;
	}

	public String getAz(){
		return az;
	}

	public void setFa(String fa){
		this.fa = fa;
	}

	public String getFa(){
		return fa;
	}

	public void setRo(String ro){
		this.ro = ro;
	}

	public String getRo(){
		return ro;
	}

	public void setNl(String nl){
		this.nl = nl;
	}

	public String getNl(){
		return nl;
	}

	public void setBa(String ba){
		this.ba = ba;
	}

	public String getBa(){
		return ba;
	}

	public void setUdm(String udm){
		this.udm = udm;
	}

	public String getUdm(){
		return udm;
	}

	public void setCeb(String ceb){
		this.ceb = ceb;
	}

	public String getCeb(){
		return ceb;
	}

	public void setNo(String no){
		this.no = no;
	}

	public String getNo(){
		return no;
	}

	public void setBe(String be){
		this.be = be;
	}

	public String getBe(){
		return be;
	}

	public void setFi(String fi){
		this.fi = fi;
	}

	public String getFi(){
		return fi;
	}

	public void setRu(String ru){
		this.ru = ru;
	}

	public String getRu(){
		return ru;
	}

	public void setBg(String bg){
		this.bg = bg;
	}

	public String getBg(){
		return bg;
	}

	public void setBn(String bn){
		this.bn = bn;
	}

	public String getBn(){
		return bn;
	}

	public void setFr(String fr){
		this.fr = fr;
	}

	public String getFr(){
		return fr;
	}

	public void setJv(String jv){
		this.jv = jv;
	}

	public String getJv(){
		return jv;
	}

	public void setBs(String bs){
		this.bs = bs;
	}

	public String getBs(){
		return bs;
	}

	public void setKa(String ka){
		this.ka = ka;
	}

	public String getKa(){
		return ka;
	}

	public void setSi(String si){
		this.si = si;
	}

	public String getSi(){
		return si;
	}

	public void setSk(String sk){
		this.sk = sk;
	}

	public String getSk(){
		return sk;
	}

	public void setSl(String sl){
		this.sl = sl;
	}

	public String getSl(){
		return sl;
	}

	public void setGa(String ga){
		this.ga = ga;
	}

	public String getGa(){
		return ga;
	}

	public void setGd(String gd){
		this.gd = gd;
	}

	public String getGd(){
		return gd;
	}

	public void setCa(String ca){
		this.ca = ca;
	}

	public String getCa(){
		return ca;
	}

	public void setSq(String sq){
		this.sq = sq;
	}

	public String getSq(){
		return sq;
	}

	public void setSr(String sr){
		this.sr = sr;
	}

	public String getSr(){
		return sr;
	}

	public void setKk(String kk){
		this.kk = kk;
	}

	public String getKk(){
		return kk;
	}

	public void setKm(String km){
		this.km = km;
	}

	public String getKm(){
		return km;
	}

	public void setSu(String su){
		this.su = su;
	}

	public String getSu(){
		return su;
	}

	public void setKn(String kn){
		this.kn = kn;
	}

	public String getKn(){
		return kn;
	}

	public void setSv(String sv){
		this.sv = sv;
	}

	public String getSv(){
		return sv;
	}

	public void setKo(String ko){
		this.ko = ko;
	}

	public String getKo(){
		return ko;
	}

	public void setMrj(String mrj){
		this.mrj = mrj;
	}

	public String getMrj(){
		return mrj;
	}

	public void setSw(String sw){
		this.sw = sw;
	}

	public String getSw(){
		return sw;
	}

	public void setGl(String gl){
		this.gl = gl;
	}

	public String getGl(){
		return gl;
	}

	public void setTa(String ta){
		this.ta = ta;
	}

	public String getTa(){
		return ta;
	}

	public void setGu(String gu){
		this.gu = gu;
	}

	public String getGu(){
		return gu;
	}

	public void setKy(String ky){
		this.ky = ky;
	}

	public String getKy(){
		return ky;
	}

	public void setCs(String cs){
		this.cs = cs;
	}

	public String getCs(){
		return cs;
	}

	public void setXh(String xh){
		this.xh = xh;
	}

	public String getXh(){
		return xh;
	}

	public void setPa(String pa){
		this.pa = pa;
	}

	public String getPa(){
		return pa;
	}

	public void setTe(String te){
		this.te = te;
	}

	public String getTe(){
		return te;
	}

	public void setCv(String cv){
		this.cv = cv;
	}

	public String getCv(){
		return cv;
	}

	public void setTg(String tg){
		this.tg = tg;
	}

	public String getTg(){
		return tg;
	}

	public void setTh(String th){
		this.th = th;
	}

	public String getTh(){
		return th;
	}

	public void setLa(String la){
		this.la = la;
	}

	public String getLa(){
		return la;
	}

	public void setCy(String cy){
		this.cy = cy;
	}

	public String getCy(){
		return cy;
	}

	public void setLb(String lb){
		this.lb = lb;
	}

	public String getLb(){
		return lb;
	}

	public void setTl(String tl){
		this.tl = tl;
	}

	public String getTl(){
		return tl;
	}

	public void setPl(String pl){
		this.pl = pl;
	}

	public String getPl(){
		return pl;
	}

	public void setDa(String da){
		this.da = da;
	}

	public String getDa(){
		return da;
	}

	public void setHe(String he){
		this.he = he;
	}

	public String getHe(){
		return he;
	}

	public void setTr(String tr){
		this.tr = tr;
	}

	public String getTr(){
		return tr;
	}

	@Override
 	public String toString(){
		return 
			"Langs{" + 
			"tt = '" + tt + '\'' + 
			",de = '" + de + '\'' + 
			",hi = '" + hi + '\'' + 
			",lo = '" + lo + '\'' + 
			",pt = '" + pt + '\'' + 
			",lt = '" + lt + '\'' + 
			",hr = '" + hr + '\'' + 
			",lv = '" + lv + '\'' + 
			",ht = '" + ht + '\'' + 
			",hu = '" + hu + '\'' + 
			",yi = '" + yi + '\'' + 
			",hy = '" + hy + '\'' + 
			",uk = '" + uk + '\'' + 
			",mg = '" + mg + '\'' + 
			",id = '" + id + '\'' + 
			",mi = '" + mi + '\'' + 
			",ur = '" + ur + '\'' + 
			",mk = '" + mk + '\'' + 
			",pap = '" + pap + '\'' + 
			",ml = '" + ml + '\'' + 
			",mn = '" + mn + '\'' + 
			",af = '" + af + '\'' + 
			",mr = '" + mr + '\'' + 
			",uz = '" + uz + '\'' + 
			",ms = '" + ms + '\'' + 
			",el = '" + el + '\'' + 
			",mt = '" + mt + '\'' + 
			",en = '" + en + '\'' + 
			",eo = '" + eo + '\'' + 
			",is = '" + is + '\'' + 
			",it = '" + it + '\'' + 
			",am = '" + am + '\'' + 
			",my = '" + my + '\'' + 
			",es = '" + es + '\'' + 
			",zh = '" + zh + '\'' + 
			",et = '" + et + '\'' + 
			",eu = '" + eu + '\'' + 
			",ar = '" + ar + '\'' + 
			",vi = '" + vi + '\'' + 
			",mhr = '" + mhr + '\'' + 
			",ja = '" + ja + '\'' + 
			",ne = '" + ne + '\'' + 
			",az = '" + az + '\'' + 
			",fa = '" + fa + '\'' + 
			",ro = '" + ro + '\'' + 
			",nl = '" + nl + '\'' + 
			",ba = '" + ba + '\'' + 
			",udm = '" + udm + '\'' + 
			",ceb = '" + ceb + '\'' + 
			",no = '" + no + '\'' + 
			",be = '" + be + '\'' + 
			",fi = '" + fi + '\'' + 
			",ru = '" + ru + '\'' + 
			",bg = '" + bg + '\'' + 
			",bn = '" + bn + '\'' + 
			",fr = '" + fr + '\'' + 
			",jv = '" + jv + '\'' + 
			",bs = '" + bs + '\'' + 
			",ka = '" + ka + '\'' + 
			",si = '" + si + '\'' + 
			",sk = '" + sk + '\'' + 
			",sl = '" + sl + '\'' + 
			",ga = '" + ga + '\'' + 
			",gd = '" + gd + '\'' + 
			",ca = '" + ca + '\'' + 
			",sq = '" + sq + '\'' + 
			",sr = '" + sr + '\'' + 
			",kk = '" + kk + '\'' + 
			",km = '" + km + '\'' + 
			",su = '" + su + '\'' + 
			",kn = '" + kn + '\'' + 
			",sv = '" + sv + '\'' + 
			",ko = '" + ko + '\'' + 
			",mrj = '" + mrj + '\'' + 
			",sw = '" + sw + '\'' + 
			",gl = '" + gl + '\'' + 
			",ta = '" + ta + '\'' + 
			",gu = '" + gu + '\'' + 
			",ky = '" + ky + '\'' + 
			",cs = '" + cs + '\'' + 
			",xh = '" + xh + '\'' + 
			",pa = '" + pa + '\'' + 
			",te = '" + te + '\'' + 
			",cv = '" + cv + '\'' + 
			",tg = '" + tg + '\'' + 
			",th = '" + th + '\'' + 
			",la = '" + la + '\'' + 
			",cy = '" + cy + '\'' + 
			",lb = '" + lb + '\'' + 
			",tl = '" + tl + '\'' + 
			",pl = '" + pl + '\'' + 
			",da = '" + da + '\'' + 
			",he = '" + he + '\'' + 
			",tr = '" + tr + '\'' + 
			"}";
		}
}