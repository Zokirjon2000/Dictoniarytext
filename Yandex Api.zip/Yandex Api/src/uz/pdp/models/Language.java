package uz.pdp.models;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Language implements Serializable {

	@SerializedName("dirs")
	private List<String> dirs;

	@SerializedName("langs")
	private Langs langs;

	public void setDirs(List<String> dirs){
		this.dirs = dirs;
	}

	public List<String> getDirs(){
		return dirs;
	}

	public void setLangs(Langs langs){
		this.langs = langs;
	}

	public Langs getLangs(){
		return langs;
	}

	@Override
 	public String toString(){
		return 
			"Language{" + 
			"dirs = '" + dirs + '\'' + 
			",langs = '" + langs + '\'' + 
			"}";
		}
}