package uz.pdp.models;

public class Word {
    private String language;
    private String word;
    private String translate;

    public Word(String language, String word, String translate) {
        this.language = language;
        this.word = word;
        this.translate = translate;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getTranslate() {
        return translate;
    }

    public void setTranslate(String translate) {
        this.translate = translate;
    }

    @Override
    public String toString() {
        return "Word{" +
                "language='" + language + '\'' +
                ", word='" + word + '\'' +
                ", translate='" + translate + '\'' +
                '}';
    }
}
