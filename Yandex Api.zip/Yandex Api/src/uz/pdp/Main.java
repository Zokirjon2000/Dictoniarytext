package uz.pdp;

import uz.pdp.service.YandexService;
import uz.pdp.service.YandexServiceImpl;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        YandexService yandexService = new YandexServiceImpl();
        while (true){
            System.out.println("1->Get langs;" +
                    "2-> Translate");
            int n = scanner.nextInt();
            switch (n){
                case 1:
                    yandexService.getLangs();
                    break;
                case 2:
                    yandexService.translate();
                    break;
            }
        }
    }
}
